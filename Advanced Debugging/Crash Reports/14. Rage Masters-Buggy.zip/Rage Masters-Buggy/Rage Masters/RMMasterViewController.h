//
//  RMMasterViewController.h
//  Rage Masters
//
//  Created by Canopus on 10/8/12.
//  Copyright (c) 2012 iOS Developer. All rights reserved.
//

#import "RMBookmarks.h"
#import "RMBookmarksViewController.h"
#import "RMDetailViewController.h"
#import "RMMaster.h"
#import <UIKit/UIKit.h>


@interface RMMasterViewController : UITableViewController

@property (strong, nonatomic) NSArray *masters;

@end
