//
//  RMDetailViewController.h
//  Rage Masters
//
//  Created by Canopus on 10/8/12.
//  Copyright (c) 2012 iOS Developer. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RMMaster.h"
#import "RMBookmarks.h"

@interface RMDetailViewController : UIViewController

@property (strong, nonatomic) RMMaster *master;

@end
