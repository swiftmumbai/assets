//
//  RMRageRequest.h
//  Rage Masters
//
//  Created by Canopus on 10/13/12.
//  Copyright (c) 2012 iOS Developer. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface RMRageRequest : NSObject

- (id)initWithImage:(UIImage *)image;

@end
